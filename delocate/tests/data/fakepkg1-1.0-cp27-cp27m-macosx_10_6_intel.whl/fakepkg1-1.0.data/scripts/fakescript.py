#!python
""" A fake script
"""

import fakepkg1.subpkg.module2


def main():
    print("Fake.  Script")


if __name__ == '__main__':
    main()
